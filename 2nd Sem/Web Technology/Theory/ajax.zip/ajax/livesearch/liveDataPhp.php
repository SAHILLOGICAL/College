<?php

$conn= mysqli_connect("localhost", "root", "","mydb");
$sql ="SELECT name,subject,marks,contcatno FROM student where name like '%".$_POST['q']."%'";
echo "<tr><th>Name</th><th>Subject</th><th>Marks</th><th>contact_no</th></tr>";
$result = mysqli_query($conn,$sql) or die(mysqli_error($conn));
if(mysqli_num_rows($result)>0){
while($row=mysqli_fetch_assoc($result))
{
	echo "  <tr>
		    <td>".$row["name"]."</td>
		    <td>".$row["subject"]."</td>	
		    <td>".$row["marks"]."</td>
		    <td>".$row["contcatno"]."</td>
		    </tr>";
}
 }
 else
 
 echo 'No records ';

?>