
<?php
$servername = "localhost";
$username = "root";
$password = "";

$conn= mysqli_connect($servername, $username, $password,"mydb") or die(mysql_error());
$sql = "update mytable set clicks=clicks+1;";
mysqli_query($conn,$sql)or die(mysql_error());

$sql = "SELECT clicks FROM mytable";
$result = mysqli_query($conn,$sql)or die(mysql_error());
$r=mysqli_fetch_assoc($result);
echo $r["clicks"];

?>