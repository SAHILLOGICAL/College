<!DOCTYPE html>
<html>
<body>

<img src="like.jpg" onclick="loadLikes()" height="50px" width="50px" >
<p id='demo'>Number of likes:
<?php
$conn= mysqli_connect("localhost", "root", "","mydb") or die(mysql_error());
$sql = "SELECT clicks FROM mytable";
$result = mysqli_query($conn,$sql)or die(mysql_error());
$r=mysqli_fetch_assoc($result);
echo $r["clicks"];
?> 
</p>
</div>

<script>
function loadLikes() {
  var xhr = new XMLHttpRequest();
  
  xhr.open("get", "sqlData.php", true);

  xhr.send();

  xhr.onload=function()
   {
		document.getElementById("demo").innerHTML="Number of likes:"+this.responseText;
   }

}

</script>

</body>
</html>
