<!DOCTYPE html>
<html>

<body>
<h1 id="demo"></h1>
<table>
	<th colspan="2">User information</th>
	<tr>
		<th>First Name is</th>
		<td><?php echo $_POST["fn"] ?></td>
	</tr>
	<tr>
		<th>last name is</th>
		<td><?php echo $_POST["ln"] ?></td>
	</tr>
	<tr>
		<th> age is</th>
		<td><?php echo $_POST["age"] ?></td>
	</tr>
</table>


</body>
</html>
