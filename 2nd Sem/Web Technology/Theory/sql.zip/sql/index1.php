<html>
<head>
<title>PHP Test</title>
</head>
<body>
<p>You are successfully registerd. congratulation.<p>
</body>
</html>