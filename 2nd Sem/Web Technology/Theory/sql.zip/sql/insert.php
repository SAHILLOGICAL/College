<?php
$servername = "localhost";
$username = "root";
$password = "";
$firstname=$_GET["fn"];
$lastname=$_GET["ln"];
//comnent: Create connection**********************************************************
$conn= mysqli_connect($servername, $username, $password,"hem");
echo "Connected successfully<br><br>";


//comment:insert data************************************************************

//$sql1="INSERT INTO Mytable (firstname,lastname) VALUES ('".$_GET["fn"]."','".$_GET["ln"]."')";
$sql1 = "INSERT INTO Mytable (firstname,lastname) VALUES ('$firstname','$lastname')";
mysqli_query($conn,$sql1);
header('Location: index1.php'); 

mysqli_close($conn);
?>