<?php

$username="root";	//Enter the username for the database (phpmyadmin)
$password="";		//Enter the password for the username 

// Default username is "root" and default password is null.
	
$hostname="localhost"; // Don't change this as your database is running on localhost
//connection to the database
$conn=mysqli_connect($hostname,$username,$password) ;


//select a database to work with
$selected = mysqli_select_db($conn,"mydb") ; // write the name of the database you are working with

$Username=$_GET['fnn']; //write the name of the field for "un" you have specified in your html code.
$Password=$_GET['pass']; //write the name of the field for "pass" you have specified in your html code.

$res=mysqli_query($conn,"SELECT username,passward FROM demo"); 
while($row = mysqli_fetch_assoc($res)) {
	
	if($Username==$row['username'] && $Password==$row['passward'])
	{
		echo "Successfully logged in"; 
		header('Location:welcome.php');
		 
	}
	
}


		echo"Userid or Password is incorrect"; // Error if nothing is entered in the username of password.
		header('Location:formphp.html');

	

?>
