<?php
$servername = "localhost";
$username = "root";
$password = "";

$conn= mysqli_connect($servername, $username, $password) or die(mysql_error());
echo "Connected successfully<br><br>";



$selected = mysqli_select_db($conn,"mydb") or die("database is not available"); 
echo "database is selected<br><br>";



$sql = "SELECT id, firstname ,lastname FROM Mytable";
$result = mysqli_query($conn,$sql)or die(mysql_error());
if ($result->num_rows > 0) {
    
    while($row = mysqli_fetch_assoc($result)) {
        echo "id: " . $row["id"]. " - FirstName: " . $row["firstname"]." -LastName: ". $row["lastname"]. "<br>";
    }
} else {
    echo "0 results";
}


//comment:delete data*******************************************************************
/*$sql = "DELETE FROM Mytable WHERE id=2";
mysqli_query($conn,$sql)or die(mysql_error());
echo "data is deleted";
*/


//comment:update data*******************************************************************
//$sql = "UPDATE Mytable SET firstname='abc' WHERE id=1";
//mysqli_query($conn,$sql)or die(mysql_error());
//echo "data is updated";

mysqli_close($conn);
?>