<?php
$servername = "localhost";
$username = "root";
$password = "";

$conn= mysqli_connect($servername, $username, $password);
echo "Connected successfully<br><br>";



$selected = mysqli_select_db($conn,"mydb"); 
echo "database is selected<br><br>";




mysqli_query($conn,"CREATE TABLE Mytable (id int(6)  AUTO_INCREMENT PRIMARY KEY,
							firstname VARCHAR(30),
							lastname varchar(30))") or die(mysql_error());
echo "table created<br><br>";

mysqli_close($conn);
?>