
<?php
$servername = "localhost";
$username = "root";
$password = "";

$conn= mysqli_connect($servername, $username, $password) or die(mysql_error());
echo "Connected successfully<br><br>";

$selected = mysqli_select_db($conn,"mydb") or die("database is not available"); 
echo "database is selected<br><br>";


$sql = "INSERT INTO Mytable (firstname,lastname) VALUES ('vaibhavi','patel')";
mysqli_query($conn,$sql)or die(mysql_error());
echo "data is inserted<br>";


mysqli_close($conn);
?>