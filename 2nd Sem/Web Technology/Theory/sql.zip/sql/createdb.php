<?php
$servername = "localhost";
$username = "root";
$password = "";

$conn= mysqli_connect($servername, $username, $password);
echo "Connected successfully<br><br>";


mysqli_query($conn,"CREATE DATABASE mydb3");
echo "database created<br><br>";
mysqli_close($conn);
?>
